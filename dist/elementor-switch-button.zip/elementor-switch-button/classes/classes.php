<?php
require_once 'class-post-type.php';
require_once 'class-taxonomy.php';